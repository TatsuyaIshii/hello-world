#include <stdio.h>
#include <stdlib.h>

int main(void){
  int events = 1000;
  int a[events][5];

  FILE *fp1;
  const char *filename1 = "e498z.dat";
  double x1[events][1];
  int index1 = 0;
  fp1 = fopen(filename1,"r");
  if(fp1 == NULL){
    printf("Can't open file %s\n",filename1);
    exit(1);
  }
  /* read data */
  while (fscanf(fp1,"%lf\n",&x1[index1][0]) !=EOF){
    a[index1][0]=x1[index1][0];
    ++index1;
      }
  fclose(fp1);

  FILE *fp2;
  const char *filename2 = "e499z.dat";
  double x2[events][1];
  int index2 = 0;
  fp2 = fopen(filename2,"r");
  if(fp2 == NULL){
    printf("Can't open file %s\n",filename2);
    exit(1);
  }
  /* read data */
  while (fscanf(fp2,"%lf\n",&x2[index2][0]) !=EOF){
    a[index2][1]=x2[index2][0];
    ++index2;
      }
  fclose(fp2);

  FILE *fp3;
  const char *filename3 = "e500z.dat";
  double x3[events][1];
  int index3 = 0;
  fp3 = fopen(filename3,"r");
  if(fp3 == NULL){
    printf("Can't open file %s\n",filename3);
    exit(1);
  }
  /* read data */
  while (fscanf(fp3,"%lf\n",&x3[index3][0]) !=EOF){
    a[index3][2]=x3[index3][0];
    ++index3;
      }
  fclose(fp3);

  FILE *fp4;
  const char *filename4 = "e501z.dat";
  double x4[events][1];
  int index4 = 0;
  fp4 = fopen(filename4,"r");
  if(fp4 == NULL){
    printf("Can't open file %s\n",filename4);
    exit(1);
  }
  /* read data */
  while (fscanf(fp4,"%lf\n",&x4[index4][0]) !=EOF){
    a[index4][3]=x4[index4][0];
    ++index4;
      }
  fclose(fp4);

  FILE *fp5;
  const char *filename5 = "e502z.dat";
  double x5[events][1];
  int index5 = 0;
  fp5 = fopen(filename5,"r");
  if(fp5 == NULL){
    printf("Can't open file %s\n",filename5);
    exit(1);
  }
  /* read data */
  while (fscanf(fp5,"%lf\n",&x5[index5][0]) !=EOF){
    a[index5][4]=x5[index5][0];
    ++index5;
      }
  fclose(fp5);

  /* write data */
  FILE *fp6;
  const char *filename6 = "rawez.dat";
  int i,j;
  fp6 = fopen(filename6,"w");
  if(fp6 == NULL){
    printf("Can't open file %s\n",filename6);
    exit(1);
  }
  for(i = 0; i < events; ++i){
    for(j = 0; j < 5; ++j){
      fprintf(fp6,"%d ",a[i][j]);
    }
    fprintf(fp6,"\n");
  }
  fclose(fp6);
  return 0;
}



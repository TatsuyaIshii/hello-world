{
  gROOT->Reset();
  gStyle->SetOptStat(1001110);

  TFile* f = new TFile("./test.root","recreate");
  TTree* tree1 = new TTree("TreeE","TreeE:raw data");
  TTree* tree2 = new TTree("TreeMu","TreeMu:raw data");

  double var1,var2,var3,var4,var5;

  tree1->Branch("var1",&var1,"var1/D");
  tree1->Branch("var2",&var2,"var2/D");
  tree1->Branch("var3",&var3,"var3/D");
  tree1->Branch("var4",&var4,"var4/D");
  tree1->Branch("var5",&var5,"var5/D");

  ifstream data ("./rawex.dat");
  while (data >> var1 >> var2 >> var3 >> var4 >>var5)tree1->Fill();

  tree2->Branch("var1",&var1,"var1/D");
  tree2->Branch("var2",&var2,"var2/D");
  tree2->Branch("var3",&var3,"var3/D");
  tree2->Branch("var4",&var4,"var4/D");
  tree2->Branch("var5",&var5,"var5/D");

  ifstream data ("./rawmx.dat");
  while (data >> var1 >> var2 >> var3 >> var4 >> var5)tree2->Fill();

  f->Write();
}
